import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class Main {
	
	public static void main(String[] args) {
		
		Input in = new Input(System.in);
		
		// compute and print here
		
		Arrays.sort(in.images, (i1, i2) -> Integer.compare(i1.timestamp, i2.timestamp));
		
		List<Output> out = new ArrayList<>();
		
		
		
		
		
		
		for (Image i : in.images) {
			if (!i.asteroide)
				continue;
			
			boolean exist = false;
			for(Output o : out) {
				if (o.ref.get(0).equalsShape(i)) {
					System.err.println(i.timestamp+"=="+o.ref.get(0).timestamp);
					// check
					if (o.checkCanGoInside(i, in.images, in.start, in.end)) {
						exist = true;
						o.ref.add(i);
						System.err.println("add     "+i.timestamp+" to " + o.minT);
						o.maxT = i.timestamp;
						o.count++;
						break;
					}
				}
				else
					System.err.println(i.timestamp+"=="+o.ref.get(0).timestamp);
			}
			
			if (!exist) {
				Output o = new Output();
				o.minT = o.maxT = i.timestamp;
				o.count = 1;
				o.ref.add(i);
				System.err.println("add new "+i.timestamp);
				out.add(o);
			}
		}
		
		
		
		for (Output o : out) {
			System.out.println(o.minT + " " + o.maxT + " " + o.count);
		}
		
		
		
	}
	
	
	
	
	
	
	static class Output {
		List<Image> ref = new ArrayList<>();
		int minT, maxT, count;
		
		boolean checkCanGoInside(Image i, Image[] all, int tMin, int tMax) {
			if (ref.size() > 1) { 
				int t0 = ref.get(0).timestamp;
				int t1 = ref.get(1).timestamp;
				int interval = t1 - t0;
				return ((i.timestamp - t0) % interval == 0);
			}
			
			int t0 = ref.get(0).timestamp;
			int t1 = i.timestamp;
			int interval = t1 - t0;
			
			if (t0 - interval >= tMin)
				return false;
			
			boolean ok = true;
			for (int t = t1 + interval; t <= tMax && ok; t += interval) {
				boolean okok = false;
				for (Image ii : all) {
					if (ii.timestamp == t)
						okok = true;
				}
				if (!okok)
					ok = false;
			}
			
			return ok;
		}
		
		
	}
	
	
}
