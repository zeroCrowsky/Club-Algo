import java.util.Arrays;

public class Image {
	int timestamp;
	int row, col;
	
	boolean asteroide = false;
	
	int[][] data;
	
	
	int minR, maxR, minC, maxC;
	boolean[][] asteroidShape;
	
	public Image(int r, int c) {
		row = r; col = c;
		
		
		minR = r; maxR = 0;
		minC = c; maxC = 0;
		
		data = new int[r][c];
	}
	
	
	
	public boolean equalsShape(Image o) {
		if (!asteroide || !o.asteroide)
			return false;

		if (Arrays.deepEquals(asteroidShape, o.asteroidShape))
			return true;

		int shapeR = asteroidShape.length;
		int shapeC = asteroidShape[0].length;

		boolean[][] asteroidShape90 = new boolean[shapeC][shapeR];
		boolean[][] asteroidShape180 = new boolean[shapeR][shapeC];
		boolean[][] asteroidShape270 = new boolean[shapeC][shapeR];
		
		for (int r = 0; r < shapeR; r++) {
			for (int c = 0; c < shapeC; c++) {
				asteroidShape90[c][shapeR-1-r] = asteroidShape[r][c];
				asteroidShape180[shapeR-1-r][shapeC-1-c] = asteroidShape[r][c];
				asteroidShape270[shapeC-1-c][r] = asteroidShape[r][c];
			}
		}
		if (Arrays.deepEquals(asteroidShape90, o.asteroidShape))
			return true;
		if (Arrays.deepEquals(asteroidShape180, o.asteroidShape))
			return true;
		if (Arrays.deepEquals(asteroidShape270, o.asteroidShape))
			return true;
		return false;
	}
	
	
	
}